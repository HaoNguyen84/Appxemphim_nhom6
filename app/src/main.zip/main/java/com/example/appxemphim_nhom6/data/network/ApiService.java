package com.example.appxemphim_nhom6.data.network;

import com.example.appxemphim_nhom6.data.model.Movie;
import com.example.appxemphim_nhom6.data.model.MovieResponse;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
public interface ApiService {

    // API to get the list of new movies
    @GET("danh-sach/phim-moi-cap-nhat?page=1")
    Call<MovieResponse> getMovies();

    // API to get movie detail based on the slug
    @GET("phim/{slug}")
    Call<MovieDetailResponse> getMovieDetail(@String("slug") String slug);


}


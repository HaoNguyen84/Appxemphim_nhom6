package com.example.appxemphim_nhom6.data.model;

public class Movie {
    private String name;
    private String originName;
    private String poster_url;  // Đúng tên với getter và setter
    private String thumbUrl;
    private int year;
    private String slug;

    public Movie(String name, String originName, String poster_url, String thumbUrl, int year) {
        this.name = name;
        this.originName = originName;
        this.poster_url = poster_url;  // Khớp tên với trường trong class
        this.thumbUrl = thumbUrl;
        this.year = year;
    }
    public Movie(String slug) {
        this.slug = slug;
    }

    public String getName() {
        return name;
    }

    public String getOriginName() {
        return originName;
    }

    public String getPosterUrl() {
        return poster_url;  // Khớp với tên biến trong class
    }

    public String getThumbUrl() {
        return thumbUrl;
    }

    public int getYear() {
        return year;
    }

}

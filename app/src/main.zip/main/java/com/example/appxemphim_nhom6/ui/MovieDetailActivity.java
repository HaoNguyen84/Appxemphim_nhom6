package com.example.appxemphim_nhom6.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.appxemphim_nhom6.R;
import com.example.appxemphim_nhom6.data.network.ApiService;
import com.example.appxemphim_nhom6.data.network.RetrofitClient;

public class MovieDetailActivity extends AppCompatActivity {

    private ImageView imageViewPoster;
    private TextView textViewTitle, textViewContent, textViewYear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);

        // Ánh xạ view
        imageViewPoster = findViewById(R.id.image_view_detail_poster);
        textViewTitle = findViewById(R.id.text_view_detail_title);
        textViewContent = findViewById(R.id.text_view_detail_content);
        textViewYear = findViewById(R.id.text_view_detail_year);

        // Nhận slug từ Intent
        Intent intent = getIntent();
        String slug = intent.getStringExtra("slug");

        // Kiểm tra xem slug có null không
        if (slug != null) {
            // Gọi API để lấy chi tiết phim từ slug
            fetchMovieDetails(slug);
        } else {
            Toast.makeText(this, "Movie not found", Toast.LENGTH_SHORT).show();
        }
    }

    // Hàm gọi API để lấy chi tiết phim
    private void fetchMovieDetails(String slug) {
        // Tạo URL từ slug
        String movieDetailUrl = "https://phimapi.com/phim/" + slug;

        // Sử dụng Retrofit để gọi API
        ApiService apiService = RetrofitClient.getApiService();
        Call<MovieDetailResponse> call = apiService.getMovieDetails(slug);

        call.enqueue(new Callback<MovieDetailResponse>() {
            @Override
            public void onResponse(Call<MovieDetailResponse> call, Response<MovieDetailResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    MovieDetailResponse movieDetail = response.body();

                    // Hiển thị dữ liệu chi tiết phim lên giao diện
                    displayMovieDetails(movieDetail);
                } else {
                    Toast.makeText(MovieDetailActivity.this, "Failed to load movie details", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<MovieDetailResponse> call, Throwable t) {
                Toast.makeText(MovieDetailActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Hàm hiển thị dữ liệu chi tiết phim
    private void displayMovieDetails(MovieDetailResponse movieDetail) {
        Glide.with(this)
                .load(movieDetail.getMovie().getPosterUrl())
                .into(imageViewPoster);
        textViewTitle.setText(movieDetail.getMovie().getName());
        textViewContent.setText(movieDetail.getMovie().getContent());
        textViewYear.setText(String.valueOf(movieDetail.getMovie().getYear()));
    }
}

package com.example.appxemphim_nhom6.data.model;

import java.util.List;

public class MovieDetailResponse {

    private boolean status;
    private MovieDetail movie;

    public boolean isStatus() {
        return status;
    }

    public MovieDetail getMovie() {
        return movie;
    }

    public class MovieDetail {
        private String name;
        private String slug;
        private String origin_name;
        private String content;
        private String poster_url;
        private int year;
        private List<String> actor;
        private List<String> director;

        // Getters
        public String getName() {
            return name;
        }

        public String getSlug() {
            return slug;
        }

        public String getOriginName() {
            return origin_name;
        }

        public String getContent() {
            return content;
        }

        public String getPosterUrl() {
            return poster_url;
        }

        public int getYear() {
            return year;
        }

        public List<String> getActor() {
            return actor;
        }

        public List<String> getDirector() {
            return director;
        }
    }
}
